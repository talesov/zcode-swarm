---
name: swarm
description: Use when the user wants one requirement developed by a self-organized team — /swarm splits it into non-overlapping task cards, the user confirms them, then a saved team workflow builds in parallel with per-card independent review, rework, and a final verification gate, tracked on an in-run board. Also covers /swarm-settings for the model roster.
---

# Swarm team development

One requirement in, a team out. The user confirms the requirement and the task cards; everything else — parallel build, independent review per card, rework on findings, the final gate — runs inside the saved team workflow, with progress on the run's board.

## When

- `/swarm <需求>` or "让团队做/并行开发这个需求" → this skill.
- The work is one unit or a couple of independent lookups → plain `Agent` calls, not this.
- Same shape repeated across many inputs (audit N modules, migrate N files) → still fine here: each input becomes a task card.

## Flow (zero-checkpoint default)

1. **Roster** — `node <swarm-config.mjs> show` prints the model roster the cards' `model` field draws from.
2. **Coarse split, fast** — planner discipline but coarse cards by default (a few minutes, not a deep dive): obvious scopes, per-difficulty model tiers, a gate command if the repo has one. Expansion picks up related work discovered mid-run. Ask only when the requirement itself is ambiguous. Fewer than 2 cards → say so, use one Agent.
3. **Validate** — `check-cards --stdin` until it passes; never bypass, never a user stop.
4. **Launch immediately** — CreateWorkflow `saved: { name: "zcode-swarm", args: { requirement, cards, gate, review_model, rework_rounds } }`. Saved-workflow runs do NOT need the dynamic-workflows skill loaded — do not load it. After launch, report the dispatched cards and tell the user they are free to go; the completion notification carries the report.
5. **Opt-in card review** — only when the user says 先过卡/给我确认 or has a standing rule: show the `--table` card table, let them retune any card's `model`, then launch.

The user touches the requirement and the final report; the only click left is the platform's run-confirmation window at launch.

## Settings

`/swarm-settings` renders the settings card (model roster, reviewer model, rework rounds); saving routes back a `set --stdin` command to run. Settings persist in `~/.zcode/zcode-swarm/settings.json` and regenerate the saved workflow; a running team is unaffected.

## Discipline (unchanged from v0.2)

One writer per file — two cards that touch the same files are one card. Read-only work needs no scope. Cards must be self-contained: the builder and reviewer never get to ask questions, so bake the criteria into `acceptance`.
