---
description: 发布一个团队开发需求：说完需求即开工——快速粗拆、校验、直接启动团队工作流，全程只在最后收报告
argument-hint: <需求描述> [先过卡] [gate: 验证命令]
---

# 团队开发（直达模式）

把 `$ARGUMENTS` 变成一次团队工作流运行。**默认零中途确认**：需求说清即开工，粗卡快拆（细节由动态扩编边干边补），你只等最终报告。仅当需求本身有歧义时才追问。

## 0. 找脚本（一次 Bash，顺手拿设置）

```bash
CFG=$(find ~/.zcode/cli/plugins/cache -name swarm-config.mjs 2>/dev/null | sort -V | tail -1)
[ -n "$CFG" ] || CFG=$(find ~/.zcode/cli/plugins -name swarm-config.mjs 2>/dev/null | sort -V | tail -1)
node "$CFG" show
```

找不到就直说插件没装好。模型名单里的档位键供拆单参考。

## 1. 快速粗拆（目标：几分钟内出卡，宁粗勿慢）

按 swarm-planner 的纪律拆，但**默认粗卡**：边界明显的直接定 scope，拿不准的不用深挖代码取证——粗一点没关系，施工员途中发现漏掉的相关工作会经扩编补位（spawn_depth 默认开）。每张卡按难度给 model 档位（简单 light / 常规 strong / 难题 hard）。

- 需求有实质歧义（做哪个版本、改哪个系统）→ 问一句再拆
- 拆不出 ≥2 张卡 → 直说"这不是 swarm"，用单个 Agent 完成，不要硬凑
- gate：项目现成的测试/构建命令（package.json / Makefile / CI 里找），没有就空着并说明

## 2. 校验（不问你，直接过）

```bash
node "$CFG" check-cards --stdin <<'JSON'
{ "cards": [ ... ] }
JSON
```

退出码 2 按提示改到通过为止，**不要绕过**。

## 3. 立即启动（不需要加载 dynamic-workflows 技能——已保存工作流的启动是唯一免加载的调用）

```
saved: { name: "zcode-swarm", args: { requirement: "...", cards: [...], gate: "...", review_model: "<show 里的值>", rework_rounds: <show 里的值> } }
```

启动后在回复里**报告已派出的卡**（编号/任务/范围/模型档位一览 + gate），然后明确告诉用户：可以走人了，完成通知会带回报告；看板在运行卡片里。运行确认窗口（平台固定行为）会在启动时弹出——那是最后一个点击。

## 例外：用户要人工过卡

`$ARGUMENTS` 里出现"先过卡 / 给我确认 / 我要过目"，或该会话用户明确立了先过卡的规矩：回到旧流程——check-cards --table 出表格给用户过目（可当场改任何一张的模型档位），点头后再走第 3 步。

## 4. 之后

不轮询。有子代理升级提问按证据回答；运行出错改脚本文件 AmendWorkflow，不从头重跑。
