---
name: swarm
description: Use when one task repeats across many independent inputs and should run in parallel — reviewing N files or modules, auditing N directories, applying the same migration or refactor to N targets, or gathering N independent research threads. Fans out one prompt template across N items as concurrent subagents, with the plan validated before anything launches so duplicate or overlapping work is impossible.
---

# Swarm

Fan one prompt template across N independent inputs, running the subagents concurrently. This is the ZCode-native equivalent of kimi-code's `AgentSwarm`.

**Reach for this when the work is the same shape repeated.** If you have a handful of *differently shaped* tasks, make separate `Agent` calls in one message instead — that is simpler and needs no protocol. If you have one unit of work, call `Agent` once.

## Locating the script

`${ZCODE_PLUGIN_ROOT}` is **not** expanded in Bash commands (it only works inside hook and MCP configuration), so never write it in a shell command. Resolve the script by discovery instead — this one-liner is self-contained and safe to repeat in every call:

```bash
SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | head -1)
```

Then call `node "$SWARM" …`. If the discovery returns nothing, the plugin is not installed where expected: apply the rules below by hand rather than skipping validation, and tell the user the script could not be found.

## Why a script instead of just launching agents

Launching N subagents is easy; the failure modes are what cost you. Two subagents given overlapping scope both edit the same files and clobber each other. Two items that expand to an identical prompt burn two subagent runs to produce one answer. A plan with one item should never have been a swarm. The script rejects all three **before** anything is launched, so a bad plan costs one script run rather than N wasted subagents.

## Workflow

### 1. Plan — validate and expand

Write the spec and let the script check it:

```bash
SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | head -1)
node "$SWARM" plan \
  --items "src/a.ts,src/b.ts,src/c.ts" \
  --template "Review {{item}} for likely regressions." \
  --description "Regression review"
```

For items that carry a scope (so overlap can be checked), pass JSON on stdin or with `--input`:

```bash
SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | head -1)
node "$SWARM" plan --stdin <<'JSON'
{
  "description": "Module refactor",
  "template": "Refactor {{item}} to use the new API. Report files changed.",
  "items": [
    { "value": "player movement", "scope": "src/game/player" },
    { "value": "UI panels",       "scope": "src/ui" }
  ]
}
JSON
```

Exit code `2` means rejected — read the reasons, fix the spec, re-run. Nothing has been launched at that point.

The command prints a rendered plan: every expanded prompt plus the plan file path. Add `--json` if you want the machine-readable form.

**What it rejects:**

| Rule | Why |
|---|---|
| Fewer than 2 items | One item is not a swarm — call `Agent` directly |
| Template missing `{{item}}` | The template would not vary per item |
| Two items expanding to the same prompt | Duplicate work, paid twice |
| Overlapping scopes | Two subagents editing the same files |
| More than 128 items (or your `--max`) | Bounded fan-out |

**When items genuinely have no natural scope** (independent research questions, separate documents), omit `scope` — the overlap check simply does not apply. Do not invent scopes to satisfy the checker.

### 2. Launch — one message, all calls

Read the rendered plan and **issue every `Agent` call in a single message** so they run concurrently. Launching them across separate messages serializes the work and defeats the point.

Each subagent gets zero context, so each prompt must be self-contained — name the files, state the goal, and say what to return. The template is a starting point; if an item needs extra context, extend that item's prompt rather than degrading the shared template.

For write-heavy swarms, pass `subagent_type: "swarm-worker"` (read-only work can stay on the default general-purpose agent).

### 3. Reconcile — item by item

When the subagents return, account for every item. Do not report the swarm as done because most of it succeeded:

```bash
SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | head -1)
node "$SWARM" mark --plan <plan.json> --id 3 --status done --note "no regressions found"
node "$SWARM" status --plan <plan.json>
```

Statuses: `done`, `failed`, `skipped`, `running`, `pending`.

Failed items are the point of this step — a swarm where 2 of 8 items failed is not a successful swarm. Retry them individually with `Agent`, or report them explicitly as outstanding.

### 4. Report

Give the user one consolidated result: what ran, what each item found, and what is still open. The subagents' own messages are not shown to the user, so their findings must be carried into your reply.

## Scope discipline

Scope overlap is the failure this protocol exists to prevent. Two useful rules:

- **One writer per file.** If two items would touch the same file, they are one item — merge them.
- **Read-only swarms can share scope.** Audits and research that only read never conflict. When nothing writes, scopes are informational; leave them off.

## Cost

A swarm of N items spends N subagent runs. That is the trade for wall-clock time. Keep N proportional to genuinely independent work — 20 items is a reasonable audit, 20 items that are all really one investigation is waste.
