#!/usr/bin/env node
/**
 * swarm-plan — the enforced half of the swarm protocol.
 *
 * The main agent decides the fan-out; this script validates it before any
 * subagent is launched, so a bad plan costs one script run instead of N
 * wasted subagents. It mirrors the rules the host enforces natively in
 * kimi-code's AgentSwarm, and adds a scope-conflict check.
 *
 *   plan      validate items + template, expand, write an auditable plan file
 *   mark      record one item's outcome (done | failed | skipped)
 *   status    show the plan's item-by-item state
 *
 * Zero dependencies. Node 18+.
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const PLACEHOLDER = '{{item}}';
const HARD_CAP = 128;
const DEFAULT_MAX = 16;
const VALID_STATUS = new Set(['pending', 'running', 'done', 'failed', 'skipped']);

function die(message, code = 2) {
  console.error(`[swarm] ERROR: ${message}`);
  process.exit(code);
}

function info(message) {
  console.error(`[swarm] ${message}`);
}

// ---------------------------------------------------------------- arguments

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      args._.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) {
      args[key] = true;
    } else {
      args[key] = next;
      i += 1;
    }
  }
  return args;
}

function readStdin() {
  try {
    return readFileSync(0, 'utf8');
  } catch {
    return '';
  }
}

// ------------------------------------------------------------------- input

/**
 * Accepts either an inline spec or a JSON document. Items may be bare strings
 * or objects carrying a per-item scope, which is what makes the overlap check
 * possible.
 */
function loadSpec(args) {
  let spec = null;

  if (args.input) {
    const path = resolve(String(args.input));
    if (!existsSync(path)) die(`input file not found: ${path}`);
    try {
      spec = JSON.parse(readFileSync(path, 'utf8'));
    } catch (error) {
      die(`input file is not valid JSON: ${error.message}`);
    }
  } else if (args.stdin) {
    const raw = readStdin().trim();
    if (!raw) die('--stdin was given but stdin was empty');
    try {
      spec = JSON.parse(raw);
    } catch (error) {
      die(`stdin is not valid JSON: ${error.message}`);
    }
  }

  const template = spec?.template ?? (typeof args.template === 'string' ? args.template : undefined);
  const subagentType = spec?.subagent_type ?? (typeof args.type === 'string' ? args.type : undefined);
  const description = spec?.description ?? (typeof args.description === 'string' ? args.description : undefined);
  const model = spec?.model ?? (typeof args.model === 'string' ? args.model : undefined);

  let items = spec?.items;
  if (items === undefined && typeof args.items === 'string') {
    items = args.items.split(',').map((value) => value.trim()).filter((value) => value.length > 0);
  }
  if (items === undefined) die('no items given — pass --items "a,b,c", --input file.json, or --stdin');

  if (!Array.isArray(items)) die('items must be an array');

  items = items.map((entry, index) => {
    if (typeof entry === 'string') {
      return { value: entry.trim(), scope: undefined, index };
    }
    if (entry && typeof entry === 'object' && typeof entry.value === 'string') {
      return {
        value: entry.value.trim(),
        scope: typeof entry.scope === 'string' ? entry.scope.trim() : undefined,
        index,
      };
    }
    die(`item ${index} must be a string or an object with a "value" field`);
    return null;
  });

  return {
    template,
    items,
    subagentType: subagentType ?? 'general-purpose',
    description: description ?? 'swarm fan-out',
    model,
    max: Number(args.max ?? DEFAULT_MAX),
  };
}

// -------------------------------------------------------------- validation

/**
 * Scope overlap is checked conservatively: exact duplicates and prefix
 * containment are rejected. A deeper glob-intersection analysis is
 * deliberately not attempted — over-reporting sends the decision back to the
 * agent, while under-reporting would silently let two subagents collide.
 */
function normalizeScope(scope) {
  return scope.replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
}

function scopesConflict(a, b) {
  const left = normalizeScope(a);
  const right = normalizeScope(b);
  if (left === right) return true;
  if (left.startsWith(`${right}/`)) return true;
  if (right.startsWith(`${left}/`)) return true;
  return false;
}

function validate(spec) {
  const problems = [];
  const { items, template, max } = spec;

  if (items.length === 0) problems.push('at least one item is required');
  if (items.length === 1) {
    problems.push(
      'a swarm needs at least 2 items — for a single unit of work call the Agent tool directly instead',
    );
  }
  if (items.length > HARD_CAP) {
    problems.push(`${items.length} items exceeds the hard cap of ${HARD_CAP}`);
  }
  if (Number.isFinite(max) && items.length > max) {
    problems.push(`${items.length} items exceeds --max ${max}`);
  }

  for (const item of items) {
    if (item.value.length === 0) problems.push(`item ${item.index + 1} is empty after trimming`);
  }

  if (typeof template !== 'string' || template.trim().length === 0) {
    problems.push(`a prompt template is required and must contain the ${PLACEHOLDER} placeholder`);
  } else if (!template.includes(PLACEHOLDER)) {
    problems.push(`the prompt template must contain the ${PLACEHOLDER} placeholder`);
  }

  // Duplicate expansion is the expensive mistake: two identical prompts burn
  // two subagent runs to produce one answer.
  const seen = new Map();
  for (const item of items) {
    const expanded = typeof template === 'string' ? template.split(PLACEHOLDER).join(item.value) : item.value;
    const key = expanded.trim();
    if (seen.has(key)) {
      problems.push(
        `items ${seen.get(key) + 1} and ${item.index + 1} expand to the same prompt — merge or differentiate them`,
      );
    } else {
      seen.set(key, item.index);
    }
  }

  const scoped = items.filter((item) => item.scope);
  for (let i = 0; i < scoped.length; i += 1) {
    for (let j = i + 1; j < scoped.length; j += 1) {
      if (scopesConflict(scoped[i].scope, scoped[j].scope)) {
        problems.push(
          `scope conflict: item ${scoped[i].index + 1} ("${scoped[i].scope}") overlaps item ${scoped[j].index + 1} ("${scoped[j].scope}")`,
        );
      }
    }
  }

  return problems;
}

// ---------------------------------------------------------------- planning

function buildPlan(spec) {
  const expanded = spec.items.map((item, position) => ({
    id: position + 1,
    item: item.value,
    scope: item.scope ?? null,
    prompt: spec.template.split(PLACEHOLDER).join(item.value),
    status: 'pending',
    note: null,
  }));

  return {
    version: 1,
    description: spec.description,
    subagent_type: spec.subagentType,
    ...(spec.model ? { model: spec.model } : {}),
    template: spec.template,
    created_at: new Date().toISOString(),
    total: expanded.length,
    agents: expanded,
  };
}

function defaultPlanPath() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return resolve(process.cwd(), '.swarm', 'plans', `${stamp}.json`);
}

function writePlan(plan, path) {
  const target = resolve(path);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, `${JSON.stringify(plan, null, 2)}\n`, 'utf8');
  return target;
}

function loadPlan(path) {
  if (!path) die('--plan <file> is required');
  const target = resolve(String(path));
  if (!existsSync(target)) die(`plan file not found: ${target}`);
  try {
    return { plan: JSON.parse(readFileSync(target, 'utf8')), path: target };
  } catch (error) {
    die(`plan file is not valid JSON: ${error.message}`);
    return null;
  }
}

// ------------------------------------------------------------------ output

function renderPlan(plan, planPath) {
  const lines = [];
  lines.push(`# Swarm plan: ${plan.description}`);
  lines.push('');
  lines.push(
    `Items: ${plan.total} | Subagent type: ${plan.subagent_type} | Plan file: ${planPath}`,
  );
  if (plan.model) lines.push(`Model: ${plan.model}`);
  lines.push('');
  lines.push(
    `Launch all ${plan.total} subagents as Agent tool calls in a SINGLE message so they run concurrently.`,
  );
  lines.push('');

  for (const agent of plan.agents) {
    lines.push(`## ${agent.id}/${plan.total} — ${agent.item}`);
    if (agent.scope) lines.push(`Scope: \`${agent.scope}\``);
    lines.push('');
    lines.push('```text');
    lines.push(agent.prompt);
    lines.push('```');
    lines.push('');
  }

  lines.push('---');
  lines.push('After every subagent returns, reconcile item by item:');
  lines.push('');
  for (const agent of plan.agents) {
    lines.push(`- [ ] ${agent.id}. ${agent.item}`);
  }
  lines.push('');
  lines.push(
    `Record each outcome with: node scripts/swarm-plan.mjs mark --plan "${planPath}" --id <n> --status done --note "..."`,
  );

  return lines.join('\n');
}

// --------------------------------------------------------------- commands

function commandPlan(args) {
  const spec = loadSpec(args);
  const problems = validate(spec);

  if (problems.length > 0) {
    console.error('[swarm] plan rejected — nothing was launched:');
    for (const problem of problems) console.error(`  - ${problem}`);
    process.exit(2);
  }

  const plan = buildPlan(spec);
  const planPath = writePlan(plan, args.out ? String(args.out) : defaultPlanPath());

  if (args.json) {
    process.stdout.write(`${JSON.stringify({ plan_path: planPath, ...plan }, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${renderPlan(plan, planPath)}\n`);
}

function commandMark(args) {
  const { plan, path } = loadPlan(args.plan);
  const id = Number(args.id);
  if (!Number.isInteger(id) || id < 1) die('--id <n> must be a positive integer');

  const status = typeof args.status === 'string' ? args.status : 'done';
  if (!VALID_STATUS.has(status)) {
    die(`--status must be one of: ${[...VALID_STATUS].join(', ')}`);
  }

  const agent = plan.agents.find((entry) => entry.id === id);
  if (!agent) die(`no item with id ${id} in ${path}`);

  agent.status = status;
  if (typeof args.note === 'string') agent.note = args.note;
  plan.updated_at = new Date().toISOString();

  writePlan(plan, path);

  const remaining = plan.agents.filter((entry) => entry.status === 'pending' || entry.status === 'running');
  info(`item ${id} -> ${status}${args.note ? ` (${args.note})` : ''}`);
  if (remaining.length === 0) {
    info(`all ${plan.total} items reconciled`);
  } else {
    info(`${remaining.length} item(s) still open: ${remaining.map((entry) => entry.id).join(', ')}`);
  }
}

function commandStatus(args) {
  const { plan, path } = loadPlan(args.plan);
  const counts = {};
  for (const agent of plan.agents) {
    counts[agent.status] = (counts[agent.status] ?? 0) + 1;
  }

  const lines = [];
  lines.push(`Plan: ${path}`);
  lines.push(`Description: ${plan.description}`);
  lines.push(
    `Progress: ${Object.entries(counts).map(([key, value]) => `${key}=${value}`).join(' ')}`,
  );
  lines.push('');
  for (const agent of plan.agents) {
    const mark = { done: '[x]', failed: '[!]', skipped: '[-]', running: '[~]', pending: '[ ]' }[agent.status];
    const note = agent.note ? ` — ${agent.note}` : '';
    lines.push(`${mark} ${agent.id}. ${agent.item}${note}`);
  }

  process.stdout.write(`${lines.join('\n')}\n`);
}

function usage() {
  process.stdout.write(`swarm-plan — validate and track a swarm fan-out

  plan    --items "a,b,c" --template "Do X for {{item}}"
          [--type general-purpose] [--description "..."] [--model "..."]
          [--max 16] [--out plan.json] [--json]
          [--input spec.json | --stdin]

  mark    --plan plan.json --id 3 --status done|failed|skipped|running|pending
          [--note "what happened"]

  status  --plan plan.json
`);
}

// ------------------------------------------------------------------- main

const argv = process.argv.slice(2);
const args = parseArgs(argv);
const command = args._[0] ?? (args.help ? 'help' : undefined);

switch (command) {
  case 'plan':
    commandPlan(args);
    break;
  case 'mark':
    commandMark(args);
    break;
  case 'status':
    commandStatus(args);
    break;
  case 'help':
  case undefined:
    usage();
    break;
  default:
    die(`unknown command "${command}" — run with --help`);
}
