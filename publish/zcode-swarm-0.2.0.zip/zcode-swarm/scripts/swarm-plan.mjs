#!/usr/bin/env node
/**
 * swarm-plan — the enforced half of the swarm protocol.
 *
 * The main agent decides the fan-out; this script validates it before any
 * subagent is launched, so a bad plan costs one script run instead of N
 * wasted subagents. It mirrors the rules the host enforces natively in
 * kimi-code's AgentSwarm, and adds a scope-conflict check.
 *
 *   plan      validate items + template, expand, write an auditable plan file
 *   mark      record outcomes (one item, a batch, or every open item)
 *   status    show the plan's item-by-item state
 *   resume    re-render prompts for items not finished (failed/running/pending)
 *   next      render the next unlaunched wave when the plan has a concurrency
 *
 * Zero dependencies. Node 18+.
 */

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const PLACEHOLDER = '{{item}}';
const HARD_CAP = 128;
const DEFAULT_MAX = 16;
const VALID_STATUS = new Set(['pending', 'running', 'done', 'failed', 'skipped']);
const OPEN_STATUS = new Set(['pending', 'running']);

function die(message, code = 2) {
  console.error(`[swarm] ERROR: ${message}`);
  process.exit(code);
}

function info(message) {
  console.error(`[swarm] ${message}`);
}

/**
 * The path to re-invoke this script with. argv[1] is passed through verbatim
 * when it is already absolute — including git-bash's /c/... form, which does
 * not survive path.resolve on win32 — and resolved against the cwd otherwise.
 */
function scriptPath() {
  const raw = process.argv[1];
  if (typeof raw !== 'string' || raw.length === 0) return 'swarm-plan.mjs';
  if (raw.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(raw)) return raw;
  return resolve(raw);
}

// ---------------------------------------------------------------- arguments

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      args._.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) {
      args[key] = true;
    } else {
      args[key] = next;
      i += 1;
    }
  }
  return args;
}

function readStdin() {
  try {
    return readFileSync(0, 'utf8');
  } catch {
    return '';
  }
}

// ------------------------------------------------------------------- input

/**
 * Accepts either an inline spec or a JSON document. Items may be bare strings
 * or objects carrying a per-item scope, which is what makes the overlap check
 * possible.
 */
function loadSpec(args) {
  let spec = null;

  if (args.input) {
    const path = resolve(String(args.input));
    if (!existsSync(path)) die(`input file not found: ${path}`);
    try {
      spec = JSON.parse(readFileSync(path, 'utf8'));
    } catch (error) {
      die(`input file is not valid JSON: ${error.message}`);
    }
  } else if (args.stdin) {
    const raw = readStdin().trim();
    if (!raw) die('--stdin was given but stdin was empty');
    try {
      spec = JSON.parse(raw);
    } catch (error) {
      die(`stdin is not valid JSON: ${error.message}`);
    }
  }

  const template = spec?.template ?? (typeof args.template === 'string' ? args.template : undefined);
  const subagentType = spec?.subagent_type ?? (typeof args.type === 'string' ? args.type : undefined);
  const description = spec?.description ?? (typeof args.description === 'string' ? args.description : undefined);
  const model = spec?.model ?? (typeof args.model === 'string' ? args.model : undefined);
  const concurrency =
    spec?.concurrency ?? (typeof args.concurrency === 'string' ? Number(args.concurrency) : undefined);

  let items = spec?.items;
  if (items === undefined && typeof args.items === 'string') {
    items = args.items.split(',').map((value) => value.trim()).filter((value) => value.length > 0);
  }
  if (items === undefined) die('no items given — pass --items "a,b,c", --input file.json, or --stdin');

  if (!Array.isArray(items)) die('items must be an array');

  items = items.map((entry, index) => {
    if (typeof entry === 'string') {
      return { value: entry.trim(), scope: undefined, index };
    }
    if (entry && typeof entry === 'object' && typeof entry.value === 'string') {
      return {
        value: entry.value.trim(),
        scope: typeof entry.scope === 'string' ? entry.scope.trim() : undefined,
        index,
      };
    }
    die(`item ${index} must be a string or an object with a "value" field`);
    return null;
  });

  return {
    template,
    items,
    subagentType: subagentType ?? 'general-purpose',
    description: description ?? 'swarm fan-out',
    model,
    concurrency,
    max: Number(args.max ?? DEFAULT_MAX),
  };
}

// -------------------------------------------------------------- validation

/**
 * Scope overlap is checked conservatively: exact duplicates and prefix
 * containment are rejected. A deeper glob-intersection analysis is
 * deliberately not attempted — over-reporting sends the decision back to the
 * agent, while under-reporting would silently let two subagents collide.
 */
function normalizeScope(scope) {
  let normalized = scope.replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
  // Windows paths are case-insensitive: src/UI and src/ui are the same scope.
  if (process.platform === 'win32') normalized = normalized.toLowerCase();
  return normalized;
}

function scopesConflict(a, b) {
  const left = normalizeScope(a);
  const right = normalizeScope(b);
  if (left === right) return true;
  if (left.startsWith(`${right}/`)) return true;
  if (right.startsWith(`${left}/`)) return true;
  return false;
}

function validate(spec) {
  const problems = [];
  const { items, template, max, concurrency } = spec;

  if (items.length === 0) problems.push('at least one item is required');
  if (items.length === 1) {
    problems.push(
      'a swarm needs at least 2 items — for a single unit of work call the Agent tool directly instead',
    );
  }
  if (items.length > HARD_CAP) {
    problems.push(`${items.length} items exceeds the hard cap of ${HARD_CAP}`);
  }
  if (Number.isFinite(max) && items.length > max) {
    problems.push(`${items.length} items exceeds --max ${max}`);
  }
  if (concurrency !== undefined && (!Number.isInteger(concurrency) || concurrency < 1)) {
    problems.push('concurrency must be a positive integer (wave size), e.g. --concurrency 5');
  }

  for (const item of items) {
    if (item.value.length === 0) problems.push(`item ${item.index + 1} is empty after trimming`);
  }

  if (typeof template !== 'string' || template.trim().length === 0) {
    problems.push(`a prompt template is required and must contain the ${PLACEHOLDER} placeholder`);
  } else if (!template.includes(PLACEHOLDER)) {
    problems.push(`the prompt template must contain the ${PLACEHOLDER} placeholder`);
  }

  // Duplicate expansion is the expensive mistake: two identical prompts burn
  // two subagent runs to produce one answer.
  const seen = new Map();
  for (const item of items) {
    const expanded = typeof template === 'string' ? template.split(PLACEHOLDER).join(item.value) : item.value;
    const key = expanded.trim();
    if (seen.has(key)) {
      problems.push(
        `items ${seen.get(key) + 1} and ${item.index + 1} expand to the same prompt — merge or differentiate them`,
      );
    } else {
      seen.set(key, item.index);
    }
  }

  const scoped = items.filter((item) => item.scope);
  for (let i = 0; i < scoped.length; i += 1) {
    for (let j = i + 1; j < scoped.length; j += 1) {
      if (scopesConflict(scoped[i].scope, scoped[j].scope)) {
        problems.push(
          `scope conflict: item ${scoped[i].index + 1} ("${scoped[i].scope}") overlaps item ${scoped[j].index + 1} ("${scoped[j].scope}")`,
        );
      }
    }
  }

  return problems;
}

// ---------------------------------------------------------------- planning

function buildPlan(spec) {
  const expanded = spec.items.map((item, position) => ({
    id: position + 1,
    item: item.value,
    scope: item.scope ?? null,
    prompt: spec.template.split(PLACEHOLDER).join(item.value),
    status: 'pending',
    note: null,
  }));

  return {
    version: 1,
    description: spec.description,
    subagent_type: spec.subagentType,
    ...(spec.model ? { model: spec.model } : {}),
    ...(Number.isInteger(spec.concurrency) && spec.concurrency >= 1 ? { concurrency: spec.concurrency } : {}),
    template: spec.template,
    created_at: new Date().toISOString(),
    total: expanded.length,
    agents: expanded,
  };
}

function defaultPlanPath() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  return resolve(process.cwd(), '.swarm', 'plans', `${stamp}.json`);
}

function writePlan(plan, path) {
  const target = resolve(path);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, `${JSON.stringify(plan, null, 2)}\n`, 'utf8');
  return target;
}

function loadPlan(path) {
  if (!path) die('--plan <file> is required');
  const target = resolve(String(path));
  if (!existsSync(target)) die(`plan file not found: ${target}`);
  try {
    return { plan: JSON.parse(readFileSync(target, 'utf8')), path: target };
  } catch (error) {
    die(`plan file is not valid JSON: ${error.message}`);
    return null;
  }
}

// ------------------------------------------------------------------ output

function waveSize(plan) {
  return Number.isInteger(plan.concurrency) && plan.concurrency >= 1 ? plan.concurrency : plan.total;
}

function splitIntoWaves(agents, size) {
  const waves = [];
  for (let i = 0; i < agents.length; i += size) waves.push(agents.slice(i, i + size));
  return waves;
}

function renderAgent(agent, total) {
  const lines = [];
  lines.push(`## ${agent.id}/${total} — ${agent.item}`);
  if (agent.scope) lines.push(`Scope: \`${agent.scope}\``);
  lines.push('');
  lines.push('```text');
  lines.push(agent.prompt);
  lines.push('```');
  lines.push('');
  return lines.join('\n');
}

function renderPlan(plan, planPath) {
  const cmd = `node "${scriptPath()}"`;
  const size = waveSize(plan);
  const waves = splitIntoWaves(plan.agents, size);
  const multiWave = waves.length > 1;

  const lines = [];
  lines.push(`# Swarm plan: ${plan.description}`);
  lines.push('');
  let meta = `Items: ${plan.total} | Subagent type: ${plan.subagent_type} | Plan file: ${planPath}`;
  if (multiWave) meta += ` | Concurrency: ${size} (${waves.length} waves)`;
  lines.push(meta);
  if (plan.model) lines.push(`Model: ${plan.model}`);
  lines.push('');

  if (multiWave) {
    lines.push('Launch one wave at a time — every Agent call of a wave goes in a SINGLE message so that wave runs concurrently.');
    lines.push('');
  } else {
    lines.push(`Launch all ${plan.total} subagents as Agent tool calls in a SINGLE message so they run concurrently.`);
    lines.push('');
  }

  waves.forEach((wave, index) => {
    if (multiWave) {
      lines.push(`# Wave ${index + 1}/${waves.length}`);
      lines.push('');
    }
    for (const agent of wave) lines.push(renderAgent(agent, plan.total));
  });

  lines.push('---');
  lines.push('Protocol after launching a batch:');
  lines.push('');
  lines.push(`1. Mark the launched batch as running: ${cmd} mark --plan "${planPath}" --ids <ids> --status running`);
  lines.push(`2. As each agent returns, reconcile it: ${cmd} mark --plan "${planPath}" --ids <ids> --status done|failed|skipped --note "..."`);
  if (multiWave) {
    lines.push(`3. Print the next unlaunched wave: ${cmd} next --plan "${planPath}"`);
    lines.push(`4. Re-render unfinished work (failed/never launched): ${cmd} resume --plan "${planPath}"`);
  } else {
    lines.push(`3. Re-render unfinished work (failed/never launched): ${cmd} resume --plan "${planPath}"`);
  }
  lines.push('');
  lines.push('Item checklist (live state lives in `status`):');
  lines.push('');
  for (const agent of plan.agents) {
    lines.push(`- [ ] ${agent.id}. ${agent.item}`);
  }
  lines.push('');

  return lines.join('\n');
}

/**
 * Shared launch block for `resume` and `next`: a subset of the plan's items,
 * ready to be turned into Agent calls, plus the marking protocol for them.
 */
function renderBatch(plan, agents, headline, planPath) {
  const cmd = `node "${scriptPath()}"`;
  const ids = agents.map((agent) => agent.id).join(',');

  const lines = [];
  lines.push(`# ${headline}`);
  lines.push('');
  lines.push(`Plan: ${planPath} | Items in this batch: ${agents.length} (ids ${ids})`);
  lines.push('');
  lines.push('Launch these as Agent tool calls in a SINGLE message so they run concurrently.');
  lines.push('');
  for (const agent of agents) lines.push(renderAgent(agent, plan.total));
  lines.push('---');
  lines.push(`1. Mark this batch as running: ${cmd} mark --plan "${planPath}" --ids ${ids} --status running`);
  lines.push(`2. As each agent returns, reconcile it: ${cmd} mark --plan "${planPath}" --ids ${ids} --status done|failed|skipped --note "..."`);
  lines.push(`3. Progress: ${cmd} status --plan "${planPath}"   |   Relaunch unfinished work: ${cmd} resume --plan "${planPath}"`);
  lines.push('');

  return lines.join('\n');
}

// --------------------------------------------------------------- commands

function commandPlan(args) {
  const spec = loadSpec(args);
  const problems = validate(spec);

  if (problems.length > 0) {
    console.error('[swarm] plan rejected — nothing was launched:');
    for (const problem of problems) console.error(`  - ${problem}`);
    process.exit(2);
  }

  const plan = buildPlan(spec);
  const planPath = writePlan(plan, args.out ? String(args.out) : defaultPlanPath());

  if (args.json) {
    process.stdout.write(`${JSON.stringify({ plan_path: planPath, ...plan }, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${renderPlan(plan, planPath)}\n`);
}

/**
 * --id 3 | --ids 1,2,3 | --all (every open item: pending or running).
 */
function resolveTargets(args, plan, path) {
  if (args.all) {
    return plan.agents.filter((entry) => OPEN_STATUS.has(entry.status));
  }
  const raw = args.ids ?? args.id;
  if (raw === undefined || raw === true) {
    die('pass --id <n>, --ids 1,2,3, or --all (every open item)');
  }
  const targets = [];
  for (const piece of String(raw).split(',').map((value) => value.trim()).filter(Boolean)) {
    const id = Number(piece);
    if (!Number.isInteger(id) || id < 1) die(`"${piece}" is not a valid item id`);
    const agent = plan.agents.find((entry) => entry.id === id);
    if (!agent) die(`no item with id ${id} in ${path}`);
    if (!targets.includes(agent)) targets.push(agent);
  }
  if (targets.length === 0) die('no item ids given');
  return targets;
}

function commandMark(args) {
  const { plan, path } = loadPlan(args.plan);

  const status = typeof args.status === 'string' ? args.status : 'done';
  if (!VALID_STATUS.has(status)) {
    die(`--status must be one of: ${[...VALID_STATUS].join(', ')}`);
  }

  const targets = resolveTargets(args, plan, path);
  if (targets.length === 0) {
    info(`nothing to mark — no open (pending/running) items remain in ${path}`);
    return;
  }

  for (const agent of targets) {
    agent.status = status;
    if (typeof args.note === 'string') agent.note = args.note;
  }
  plan.updated_at = new Date().toISOString();
  writePlan(plan, path);

  const ids = targets.map((agent) => agent.id).join(',');
  info(`marked ${targets.length} item(s) [${ids}] -> ${status}${args.note ? ` (${args.note})` : ''}`);

  const remaining = plan.agents.filter((entry) => OPEN_STATUS.has(entry.status));
  if (remaining.length === 0) {
    info(`all ${plan.total} items reconciled`);
  } else {
    info(`${remaining.length} open item(s): ${remaining.map((entry) => entry.id).join(', ')}`);
  }
}

function countByStatus(plan) {
  const counts = {};
  for (const agent of plan.agents) {
    counts[agent.status] = (counts[agent.status] ?? 0) + 1;
  }
  return counts;
}

function commandStatus(args) {
  const { plan, path } = loadPlan(args.plan);
  const counts = countByStatus(plan);

  if (args.json) {
    process.stdout.write(`${JSON.stringify({
      plan_path: path,
      description: plan.description,
      total: plan.total,
      concurrency: plan.concurrency ?? null,
      counts,
      agents: plan.agents.map(({ id, item, status, note }) => ({ id, item, status, note })),
    }, null, 2)}\n`);
    return;
  }

  const lines = [];
  lines.push(`Plan: ${path}`);
  lines.push(`Description: ${plan.description}`);
  lines.push(
    `Progress: ${Object.entries(counts).map(([key, value]) => `${key}=${value}`).join(' ')}`,
  );
  lines.push('');
  for (const agent of plan.agents) {
    const mark = { done: '[x]', failed: '[!]', skipped: '[-]', running: '[~]', pending: '[ ]' }[agent.status];
    const note = agent.note ? ` — ${agent.note}` : '';
    lines.push(`${mark} ${agent.id}. ${agent.item}${note}`);
  }

  process.stdout.write(`${lines.join('\n')}\n`);
}

/**
 * Re-render launch blocks for items that never finished. Default filter is
 * failed+running+pending: everything not done or skipped. A `running` item is
 * one whose wave was launched but never reconciled (e.g. the session died).
 */
function commandResume(args) {
  const { plan, path } = loadPlan(args.plan);

  const targets = args.all || args.ids !== undefined || args.id !== undefined
    ? resolveTargets(args, plan, path)
    : (() => {
        const filter = String(args.status ?? 'failed,running,pending')
          .split(',').map((value) => value.trim()).filter(Boolean);
        for (const value of filter) {
          if (!VALID_STATUS.has(value)) die(`unknown status "${value}" in --status`);
        }
        return plan.agents.filter((entry) => filter.includes(entry.status));
      })();

  if (targets.length === 0) {
    const counts = countByStatus(plan);
    info(`nothing to resume — no item matches (plan has: ${Object.entries(counts).map(([k, v]) => `${k}=${v}`).join(' ') || 'no items'})`);
    return;
  }

  process.stdout.write(`${renderBatch(plan, targets, `Swarm resume: ${plan.description}`, path)}\n`);
  const failed = targets.filter((entry) => entry.status === 'failed').length;
  if (failed > 0) info(`${failed} previously failed item(s) in this batch — consider adjusting their prompts if the failure repeats`);
}

/**
 * Print the next unlaunched wave: the first `concurrency` pending items (or
 * --limit to override). Items already marked running are in flight, not
 * pending, so they are never re-issued here.
 */
function commandNext(args) {
  const { plan, path } = loadPlan(args.plan);

  let limit = waveSize(plan);
  if (args.limit !== undefined) {
    limit = Number(args.limit);
    if (!Number.isInteger(limit) || limit < 1) die('--limit must be a positive integer');
  }

  const pending = plan.agents.filter((entry) => entry.status === 'pending');
  if (pending.length === 0) {
    const running = plan.agents.filter((entry) => entry.status === 'running');
    if (running.length > 0) {
      info(`${running.length} item(s) still marked running — awaiting reconciliation: ${running.map((entry) => entry.id).join(', ')}`);
    } else {
      info('no pending items remain — use `resume` for failed items or `status` for the final state');
    }
    return;
  }

  const batch = pending.slice(0, limit);
  process.stdout.write(`${renderBatch(plan, batch, `Swarm next wave: ${plan.description}`, path)}\n`);
  const left = pending.length - batch.length;
  if (left > 0) info(`${left} pending item(s) after this wave`);
}

function usage() {
  process.stdout.write(`swarm-plan — validate and track a swarm fan-out

  plan    --items "a,b,c" --template "Do X for {{item}}"
          [--type general-purpose] [--description "..."] [--model "..."]
          [--max 16] [--concurrency 5] [--out plan.json] [--json]
          [--input spec.json | --stdin]

  mark    --plan plan.json (--id 3 | --ids 1,2,3 | --all)
          [--status done|failed|skipped|running|pending] [--note "..."]
          (--all targets every open item: pending or running)

  status  --plan plan.json [--json]

  resume  --plan plan.json [--ids 1,2] [--status failed,pending]
          re-render launch blocks for unfinished items
          (default filter: failed,running,pending)

  next    --plan plan.json [--limit K]
          render the next unlaunched wave (batch size = plan concurrency)
`);
}

// ------------------------------------------------------------------- main

const argv = process.argv.slice(2);
const args = parseArgs(argv);
const command = args._[0] ?? (args.help ? 'help' : undefined);

switch (command) {
  case 'plan':
    commandPlan(args);
    break;
  case 'mark':
    commandMark(args);
    break;
  case 'status':
    commandStatus(args);
    break;
  case 'resume':
    commandResume(args);
    break;
  case 'next':
    commandNext(args);
    break;
  case 'help':
  case undefined:
    usage();
    break;
  default:
    die(`unknown command "${command}" — run with --help`);
}
