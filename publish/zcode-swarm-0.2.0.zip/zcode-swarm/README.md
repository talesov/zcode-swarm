# zcode-swarm

模板化的并行子代理扇出插件。一个提示词模板 + N 个互不相同的输入 → 同时拉起 N 个子代理，各干各的，绝不重复劳动。

这是 kimi-code `AgentSwarm` 的 ZCode 原生等价物：ZCode 本身已经支持在一条消息里并发多个 `Agent` 调用，本插件补上原生扇出缺少的那部分——**启动前的计划校验**。

## 它解决什么

同时开 N 个子代理很容易，代价在失败模式上：

- 两个子代理范围重叠 → 同时改同一批文件，互相覆盖
- 两个 item 展开成完全相同的提示词 → 花两份钱得到一份答案
- 只有一个 item 的计划 → 本来就不该叫 swarm

`scripts/swarm-plan.mjs` 在**任何东西被启动之前**拦掉这三种情况。一个坏计划只花一次脚本调用的成本，而不是 N 个白跑的子代理。

## 安装

本仓库是"仓库即市场"结构，`marketplace.json` 在根目录。

1. ZCode → **Settings → Plugin Management** → **Discover** 标签页
2. 点 **`+`** 按钮添加市场，选 **local directory**，指向本目录
3. 在列表里找到 `zcode-swarm`，点安装并启用
4. 重载会话

安装后得到三个组件：

| 组件 | 形态 | 触发方式 |
|---|---|---|
| `swarm` skill | 主代理操作手册 | 任务符合"同一件事重复 N 遍"时自动加载 |
| `/swarm` 命令 | 斜杠命令 | 手动输入 `/swarm <重复的事> across <N 个输入>` |
| `swarm-worker` 子代理 | 子代理定义 | 由 skill/命令在扇出时指定 |

## 用法

最省事的是直接用命令：

```
/swarm 审查 src/ 下每个模块的回归风险 across src/game, src/ui, src/net
```

命令会先把计划交给脚本校验，把展开后的提示词给你看，再并发启动。

脚本也可以单独用：

```bash
SWARM=$(find ~/.zcode/cli/plugins/cache -name swarm-plan.mjs 2>/dev/null | sort -V | tail -1)
[ -n "$SWARM" ] || SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | sort -V | tail -1)

node "$SWARM" plan \
  --items "src/a.ts,src/b.ts,src/c.ts" \
  --template "Review {{item}} for likely regressions." \
  --description "Regression review"
```

需要检查范围重叠时，用 JSON 给 item 带上 `scope`：

```bash
node "$SWARM" plan --stdin <<'JSON'
{
  "description": "Module refactor",
  "template": "Refactor {{item}} to use the new API. Report files changed.",
  "items": [
    { "value": "player movement", "scope": "src/game/player" },
    { "value": "UI panels",       "scope": "src/ui" }
  ]
}
JSON
```

退出码 `2` = 被拦下，此时**没有启动任何子代理**。按输出的理由改计划再跑。

### 回收进度

```bash
node "$SWARM" mark   --plan <plan.json> --ids 1,2,3 --status done --note "no regressions found"
node "$SWARM" mark   --plan <plan.json> --all --status done   # 所有在飞/待办项一次收账
node "$SWARM" status --plan <plan.json> --json
```

状态：`done` / `failed` / `skipped` / `running` / `pending`。`--ids` 批量、`--id` 单个、`--all` 一次收所有未结项（pending/running）。计划默认落在 `.swarm/plans/<时间戳>.json`。

### 并发波次（可选）

N 很大、担心触发限流时，让计划带并发数：渲染输出按每波 K 个分波，`next` 逐波吐出未启动的 item。启动一波后立刻 `mark --ids ... --status running`——会话中途崩了，`status` 能看出哪些已启动却没回来。

```bash
node "$SWARM" plan --items "..." --template "..." --concurrency 5
node "$SWARM" next  --plan <plan.json>   # 下一波未启动的 item
```

波次只是视图，不是强制限流器——每波何时发由主代理决定。

### 重跑失败项

失败/漏跑的 item 不用手抄提示词，`resume` 把原始展开提示词重新渲染成可直接启动的块：

```bash
node "$SWARM" resume --plan <plan.json>                    # 所有未完成项（failed/running/pending）
node "$SWARM" resume --plan <plan.json> --status failed    # 只重跑失败的
```

## 校验规则

| 规则 | 原因 |
|---|---|
| 少于 2 个 item | 单个任务直接调 `Agent` |
| 模板不含 `{{item}}` | 模板不会随 item 变化 |
| 两个 item 展开后提示词相同 | 重复劳动，付两份钱 |
| scope 重叠（完全相同或前缀包含） | 两个子代理改同一批文件 |
| 超过 128 个（或 `--max` 指定值） | 扇出有上限 |

item 本身没有天然范围时（独立调研问题、互不相干的文档）**不要写 scope**——重叠检查自然不适用。不要为了通过检查而编造 scope。

## 边界

- **子代理看不到彼此。** 扇出是单向的：主代理派活、收结果。同伴之间没有通信，也没有 worker 之间的唤醒。这是 ZCode 的能力边界，不是本插件的省略。
- **不做强制限流。** `--concurrency K` 只提供波次视图（见上），每波何时发由主代理决定；N 个 item 就是 N 次子代理运行，请让 N 与真正独立的工作量成正比。
- **写操作要守"一文件一写者"。** 两个 item 会碰同一个文件时，它们其实是同一个 item，合并掉。
- **只读扇出可以共享范围。** 审计和调研只读不写，不会冲突。

## 依赖

零依赖，只需要 Node 18+。脚本不联网、不读配置、不碰 API key。
