---
description: Fan one prompt template across N independent inputs as concurrent subagents, with the plan validated before launch
argument-hint: <what repeats> across <the N inputs>
---

# Swarm fan-out

Turn `$ARGUMENTS` into a validated swarm plan and launch it.

## 1. Derive the spec

From the request, work out three things and state them back before running anything:

- **The N inputs** — the concrete, distinct things each subagent gets. If you cannot enumerate them, stop and ask; a vague swarm is N subagents doing the same work.
- **The template** — one instruction covering the repeated shape, containing the literal placeholder `{{item}}`.
- **The scope** — which files or directories each item owns. Include it only when subagents will *write*. Read-only work has no conflicts, so leave scope off.

If the request resolves to a single unit of work, say so and use `Agent` directly — do not force it into a swarm. If it resolves to a handful of differently shaped tasks, use separate `Agent` calls in one message.

## 2. Validate

```bash
SWARM=$(find ~/.zcode/cli/plugins/cache -name swarm-plan.mjs 2>/dev/null | sort -V | tail -1)
[ -n "$SWARM" ] || SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | sort -V | tail -1)
node "$SWARM" plan --stdin <<'JSON'
{ "description": "...", "template": "... {{item}} ...", "items": [ ... ] }
JSON
```

Exit `2` means rejected and nothing was launched. Read the reasons, fix the spec, re-run. Never bypass a rejection by launching the agents anyway — the rejection is the value of this step.

Show the user the rendered plan (the expanded prompts and the item count) before spending the subagent runs, unless they already asked you to just run it.

## 3. Launch

Read the plan and issue **every `Agent` call in a single message** so they run concurrently. One call per item, each prompt self-contained, `subagent_type: "swarm-worker"` for write-heavy work.

If the plan carries a concurrency, launch **one wave at a time** instead — the wave's Agent calls still share a single message. Right after launching any batch, mark it in flight in one call (`mark --plan <plan.json> --ids <ids> --status running`); once the wave is reconciled, `next --plan <plan.json>` prints the next unlaunched wave.

## 4. Reconcile and report

Mark outcomes batch-wise as agents return:

```bash
SWARM=$(find ~/.zcode/cli/plugins/cache -name swarm-plan.mjs 2>/dev/null | sort -V | tail -1)
[ -n "$SWARM" ] || SWARM=$(find ~/.zcode/cli/plugins -name swarm-plan.mjs 2>/dev/null | sort -V | tail -1)
node "$SWARM" mark --plan <plan.json> --ids 1,2 --status done --note "..."
node "$SWARM" mark --plan <plan.json> --all --status done   # every open item at once
node "$SWARM" status --plan <plan.json>                     # --json for machine-readable state
```

Then give one consolidated report: what ran, what each item found or changed, and what is still open. Failed items must be named explicitly — they are not folded into a success summary. Retry failures with `node "$SWARM" resume --plan <plan.json>` (re-prints their original prompts as launch blocks; `--status failed` narrows to failures only), or list them as outstanding.
