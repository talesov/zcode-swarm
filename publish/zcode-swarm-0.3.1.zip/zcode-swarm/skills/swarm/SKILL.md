---
name: swarm
description: Use when the user wants one requirement developed by a self-organized team — /swarm splits it into non-overlapping task cards, the user confirms them, then a saved team workflow builds in parallel with per-card independent review, rework, and a final verification gate, tracked on an in-run board. Also covers /swarm-settings for the model roster.
---

# Swarm team development

One requirement in, a team out. The user confirms the requirement and the task cards; everything else — parallel build, independent review per card, rework on findings, the final gate — runs inside the saved team workflow, with progress on the run's board.

## When

- `/swarm <需求>` or "让团队做/并行开发这个需求" → this skill.
- The work is one unit or a couple of independent lookups → plain `Agent` calls, not this.
- Same shape repeated across many inputs (audit N modules, migrate N files) → still fine here: each input becomes a task card.

## Flow

1. **Roster** — `node <swarm-config.mjs> show` prints the model roster the cards' `model` field draws from.
2. **Split** — apply the swarm-planner discipline yourself when the boundaries are obvious; otherwise launch one `swarm-planner` subagent (read-only). Fewer than 2 non-overlapping cards is not a swarm — say so and use a single Agent.
3. **Validate + user sign-off (拍板点)** — `check-cards --stdin --table` rejects overlaps, unknown model keys, missing fields; fix until it passes, never bypass. Show the table, the split rationale, and the proposed `gate` command. The user may retune any card's `model` right here — that is the per-task model entry.
4. **Launch** — CreateWorkflow with `saved: { name: "zcode-swarm", args: { requirement, cards, gate, review_model, rework_rounds } }`. The confirmation window is the final sign-off. Dynamic expansion is on by default (`spawn_depth: 1`): builders report related work discovered mid-task, an expansion triage agent mints validated new cards (depth/total capped), and new workers join the board live.
5. **After** — do not poll. The board (待施工/施工中/审查中/返工中/通过/未通过) lives on the run card; the completion notification carries the final report. Answer subagent escalations on their evidence; on errors amend the run's script file (AmendWorkflow), never restart from scratch.

## Settings

`/swarm-settings` renders the settings card (model roster, reviewer model, rework rounds); saving routes back a `set --stdin` command to run. Settings persist in `~/.zcode/zcode-swarm/settings.json` and regenerate the saved workflow; a running team is unaffected.

## Discipline (unchanged from v0.2)

One writer per file — two cards that touch the same files are one card. Read-only work needs no scope. Cards must be self-contained: the builder and reviewer never get to ask questions, so bake the criteria into `acceptance`.
