---
description: 发布一个团队开发需求：拆单成任务卡、你确认后用团队工作流并行施工、独立审查、统一验证
argument-hint: <需求描述> [模型档位提示] [验证命令]
---

# 团队开发

把 `$ARGUMENTS` 变成一次团队工作流运行：你只出现在需求确认和任务卡确认两个点，中间的分头施工、独立审查、返工和整体验证都在工作流里跑，进度看运行卡片里的「团队任务看板」。

## 0. 找脚本与当前设置

```bash
CFG=$(find ~/.zcode/cli/plugins/cache -name swarm-config.mjs 2>/dev/null | sort -V | tail -1)
[ -n "$CFG" ] || CFG=$(find ~/.zcode/cli/plugins -name swarm-config.mjs 2>/dev/null | sort -V | tail -1)
node "$CFG" show
```

`show` 打印当前模型名单（任务卡的 model 字段从这里取）。两个搜索都为空说明插件没装好——直说，别猜路径。

## 1. 拆单

需求已经明确成可拆的任务时，自己按 swarm-planner 的纪律拆；拿不准边界时派一个 `swarm-planner` 子代理（只读取证）。拆不出 ≥2 张互不重叠的任务卡，就直说"这不是 swarm"，改用单个 Agent——不要硬凑。

任务卡字段：`id / title / task / scope（写入范围，可为空）/ acceptance（验收判据，写死）/ role（角色名）/ model（模型名单键，按任务难度选）`。

## 2. 校验并给用户确认（拍板点）

```bash
node "$CFG" check-cards --stdin --table <<'JSON'
{ "cards": [ ... ] }
JSON
```

退出码 2 会列出全部问题（范围重叠、模型不在名单、缺字段）——按提示改到通过为止，**不要绕过校验直接启动**。通过后把表格 + 拆单理由 + 建议的验证命令（gate，没有就明说）一起给用户过目。用户对某张卡的模型有别的想法，当场改 `model` 字段再校验一次——这就是"每次任务改模型"的入口。用户点头后才进入下一步。

## 3. 启动团队工作流

用 CreateWorkflow 以已保存工作流启动（需要 dynamic-workflows 技能已加载；这是用户显式的工作流触发）：

```
saved: { name: "zcode-swarm", args: { requirement: "...", cards: [...], gate: "...", review_model: "...", rework_rounds: N } }
```

`review_model` 与 `rework_rounds` 用 `show` 里的设置值；启动确认窗口就是用户对方案的最后确认。

## 4. 之后

不要轮询运行。看板（待施工/施工中/审查中/返工中/通过/未通过）在运行卡片里实时更新；完成通知会带回最终报告（通过几张、验证命令结果、需要用户处理的清单）。有子代理中途升级提问时按其证据回答。运行出错时改运行脚本文件并用 AmendWorkflow 修正，不要从头重跑。
