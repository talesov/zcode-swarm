---
description: 打开 zcode-swarm 团队开发的设置卡片（模型名单、审查员模型、返工轮数）
---

# 团队开发设置

给用户一张会话内设置卡片，改完点「保存设置」即生效。

## 1. 准备

```bash
CFG=$(find ~/.zcode/cli/plugins/cache -name swarm-config.mjs 2>/dev/null | sort -V | tail -1)
[ -n "$CFG" ] || CFG=$(find ~/.zcode/cli/plugins -name swarm-config.mjs 2>/dev/null | sort -V | tail -1)
```

找不到就直说插件没装好。

## 2. 生成卡片

`card` 需要当前可用模型名单和会话供应商（用于跨供应商计费提示）：

- 用 ListModels 工具拿模型列表，把它的 JSON 存到临时文件（会话可视化目录或系统临时目录均可，用完即删）；
- 会话供应商取 ListModels 里标注 `[current]` 那条的 `providerId` 部分（`:` 之前或 `/` 之前的那段，与模型 id 的写法保持一致）。

```bash
node "$CFG" card --models-file <models.json> --session-provider <provider> --out <可视化目录>/swarm-settings.html
```

## 3. 展示

在最终回复正文单独一行输出（可视化目录的绝对路径，正斜杠）：

```
::visualize{"path":"<绝对路径>/swarm-settings.html"}
```

卡片里用户改档位、加自定义档位（可选手动填 providerId/modelId）、选审查员模型和返工轮数，点「保存设置」会把一条 `node "$CFG" set --stdin` 命令经确认对话框发回本会话——你执行它，把脚本打印的结果（已保存 + 重新生成的工作流路径）告诉用户。保存后新任务立即用新名单；正在运行的团队不受影响。

不需要卡片时也可以 `node "$CFG" show` 直接看当前设置。
