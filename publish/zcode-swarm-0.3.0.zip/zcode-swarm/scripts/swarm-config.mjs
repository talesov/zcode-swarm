#!/usr/bin/env node
/**
 * swarm-config — zcode-swarm 的设置与团队工作流渲染。
 *
 * 设置存在 ~/.zcode/zcode-swarm/settings.json（插件升级不丢）。团队工作流里的模型
 * 必须是脚本里的字面量，所以每次改设置都按模板重新生成已保存工作流
 * ~/.zcode/workflows/zcode-swarm.dwf.ts，只替换 @@SWARM_MODELS 块。
 *
 *   show [--json]                          当前设置（缺省值兜底）
 *   set (--stdin | --json <str> | --file <path>)   校验、保存、重新生成工作流
 *   reset                                  恢复默认设置并重新生成
 *   render [--quiet]                       按设置重新生成工作流
 *   ensure [--quiet]                       工作流缺失或模板/设置变了才重新生成（SessionStart 钩子用）
 *   check-cards (--stdin | --file <path>) [--table]   启动前校验任务卡
 *   card --models-file <path> --out <path>  生成会话内设置卡片
 *
 * 零依赖，Node 18+。
 */

import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const TEMPLATE = resolve(HERE, '..', 'workflows', 'zcode-swarm.dwf.ts');
const SETTINGS_DIR = join(homedir(), '.zcode', 'zcode-swarm');
const SETTINGS = join(SETTINGS_DIR, 'settings.json');
const OUTPUT = join(homedir(), '.zcode', 'workflows', 'zcode-swarm.dwf.ts');

const TIERS = ['light', 'strong', 'hard'];
const TIER_NAMES = { light: '轻量', strong: '常规', hard: '攻坚' };
const DEFAULTS = {
  version: 1,
  models: { light: 'GLM-5.3-Flash', strong: 'GLM-5.3$high', hard: 'GLM-5.3$max' },
  review_model: 'strong',
  rework_rounds: 2,
};
const KEY_RE = /^[a-z][a-z0-9_-]{0,31}$/;
const MODEL_ID_RE = /^[A-Za-z0-9][A-Za-z0-9:._\-/]*(\$[a-z]+)?$/;
const MAX_MODELS = 12;
const BLOCK_RE = /^\/\/ @@SWARM_MODELS_BEGIN.*\r?\n[\s\S]*?^\/\/ @@SWARM_MODELS_END[^\n]*$/m;

function die(message, code = 2) {
  console.error(`[swarm-config] ERROR: ${message}`);
  process.exit(code);
}

function info(message, quiet = false) {
  if (!quiet) console.error(`[swarm-config] ${message}`);
}

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      args._.push(token);
      continue;
    }
    const key = token.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) {
      args[key] = true;
    } else {
      args[key] = next;
      i += 1;
    }
  }
  return args;
}

function sha12(text) {
  return createHash('sha256').update(text).digest('hex').slice(0, 12);
}

function writeAtomic(path, content) {
  mkdirSync(dirname(path), { recursive: true });
  const tmp = `${path}.tmp-${process.pid}`;
  writeFileSync(tmp, content, 'utf8');
  renameSync(tmp, path);
}

/** "GLM-5.3$high" → "GLM-5.3 high"；"provider/model$max" → "model max（provider）"。 */
export function modelLabel(id) {
  const [base, level] = id.split('$');
  const slash = base.indexOf('/');
  const name = slash >= 0 ? base.slice(slash + 1) : base;
  const provider = slash >= 0 ? base.slice(0, slash).replace(/^account:/, '') : '';
  return `${name}${level ? ` ${level}` : ''}${provider ? `（${provider}）` : ''}`;
}

/** 校验并规范化设置；problems 非空时 settings 不可用。 */
export function validateSettings(raw) {
  const problems = [];
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { settings: null, problems: ['设置必须是 JSON 对象'] };
  }
  for (const key of Object.keys(raw)) {
    if (!['version', 'models', 'review_model', 'rework_rounds'].includes(key)) problems.push(`未知字段：${key}`);
  }
  const models = {};
  const rawModels = raw.models;
  if (!rawModels || typeof rawModels !== 'object' || Array.isArray(rawModels)) {
    problems.push('models 必须是对象：{ 档位键: 模型 id }');
  } else {
    const keys = Object.keys(rawModels);
    if (keys.length > MAX_MODELS) problems.push(`模型名单最多 ${MAX_MODELS} 个，当前 ${keys.length} 个`);
    for (const tier of TIERS) if (!keys.includes(tier)) problems.push(`缺少必需档位：${tier}`);
    const ordered = [...TIERS.filter((tier) => keys.includes(tier)), ...keys.filter((k) => !TIERS.includes(k)).sort()];
    for (const key of ordered) {
      const id = typeof rawModels[key] === 'string' ? rawModels[key].trim() : '';
      if (!KEY_RE.test(key)) problems.push(`档位键「${key}」只能用小写字母开头的字母、数字、-、_（最长 32）`);
      else if (!MODEL_ID_RE.test(id)) problems.push(`档位「${key}」的模型 id 不合法：${JSON.stringify(rawModels[key])}`);
      else models[key] = id;
    }
  }
  const review = typeof raw.review_model === 'string' ? raw.review_model.trim() : DEFAULTS.review_model;
  if (!Object.prototype.hasOwnProperty.call(models, review)) problems.push(`review_model「${review}」不在模型名单里`);
  const rounds = raw.rework_rounds === undefined ? DEFAULTS.rework_rounds : raw.rework_rounds;
  if (!Number.isInteger(rounds) || rounds < 0 || rounds > 5) problems.push('rework_rounds 必须是 0 到 5 的整数');
  if (problems.length > 0) return { settings: null, problems };
  return { settings: { version: 1, models, review_model: review, rework_rounds: rounds }, problems };
}

export function loadSettings() {
  if (!existsSync(SETTINGS)) return { settings: structuredClone(DEFAULTS), source: 'defaults' };
  let raw;
  try {
    raw = JSON.parse(readFileSync(SETTINGS, 'utf8'));
  } catch (error) {
    die(`设置文件不是合法 JSON：${SETTINGS}（${error.message}）——可用 reset 恢复默认`);
  }
  const { settings, problems } = validateSettings(raw);
  if (!settings) die(`设置文件无效：${SETTINGS}\n  - ${problems.join('\n  - ')}\n——可用 reset 恢复默认`);
  return { settings, source: SETTINGS };
}

function renderBlock(settings, templateSha, settingsSha) {
  const lines = [`// @@SWARM_MODELS_BEGIN template=${templateSha} settings=${settingsSha}（由 swarm-config.mjs 生成）`];
  lines.push('const MODELS: Record<string, ModelRef> = {');
  for (const [key, id] of Object.entries(settings.models)) lines.push(`  ${JSON.stringify(key)}: model(${JSON.stringify(id)}),`);
  lines.push('};', 'const MODEL_LABELS: Record<string, string> = {');
  for (const [key, id] of Object.entries(settings.models)) lines.push(`  ${JSON.stringify(key)}: ${JSON.stringify(modelLabel(id))},`);
  lines.push('};', '// @@SWARM_MODELS_END');
  return lines.join('\n');
}

function renderedStamp(settings) {
  if (!existsSync(TEMPLATE)) die(`找不到工作流模板：${TEMPLATE}`);
  const template = readFileSync(TEMPLATE, 'utf8');
  if (!BLOCK_RE.test(template)) die(`工作流模板缺少 @@SWARM_MODELS 块：${TEMPLATE}`);
  return { template, templateSha: sha12(template), settingsSha: sha12(JSON.stringify(settings)) };
}

export function render(settings, quiet = false) {
  const { template, templateSha, settingsSha } = renderedStamp(settings);
  const output = template.replace(BLOCK_RE, renderBlock(settings, templateSha, settingsSha));
  writeAtomic(OUTPUT, output);
  info(`团队工作流已按设置生成：${OUTPUT}`, quiet);
  return OUTPUT;
}

function ensure(quiet) {
  const { settings } = loadSettings();
  const { templateSha, settingsSha } = renderedStamp(settings);
  if (existsSync(OUTPUT)) {
    const head = /@@SWARM_MODELS_BEGIN template=(\w+) settings=(\w+)/.exec(readFileSync(OUTPUT, 'utf8'));
    if (head && head[1] === templateSha && head[2] === settingsSha) {
      info('团队工作流已是最新，无需重新生成', quiet);
      return;
    }
  }
  render(settings, quiet);
}

function readInput(args) {
  let raw;
  if (args.stdin) raw = readFileSync(0, 'utf8');
  else if (typeof args.file === 'string') {
    const path = resolve(args.file);
    if (!existsSync(path)) die(`找不到输入文件：${path}`);
    raw = readFileSync(path, 'utf8');
  } else if (typeof args.json === 'string') raw = args.json;
  else die('需要 --stdin、--file <path> 或 --json <字符串>');
  try {
    return JSON.parse(raw);
  } catch (error) {
    return die(`输入不是合法 JSON：${error.message}`);
  }
}

function str(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return typeof value === 'string' ? value.trim() : '';
}

/** 与 swarm-plan.mjs / 团队工作流同一套写入范围规则：相同或父子包含即重叠，大小写与斜杠方向不敏感。 */
function normalizePath(value) {
  return value.replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '').toLowerCase();
}

function inScope(path, scope) {
  const p = normalizePath(path);
  const s = normalizePath(scope);
  return s.length > 0 && (p === s || p.startsWith(`${s}/`));
}

/** 启动前校验任务卡，返回规范化后的卡（编号转成字符串、补默认角色和档位）。 */
export function checkCards(input, settings) {
  const list = Array.isArray(input) ? input : input && Array.isArray(input.cards) ? input.cards : null;
  if (!list || list.length === 0) return { cards: [], problems: ['需要非空的任务卡数组，或 { "cards": [...] }'] };
  const problems = [];
  const seen = new Set();
  const cards = list.map((entry, index) => {
    const rec = entry && typeof entry === 'object' ? entry : {};
    if (rec !== entry) problems.push(`第 ${index + 1} 张任务卡不是对象`);
    const card = {
      id: str(rec.id) || String(index + 1),
      title: str(rec.title),
      task: str(rec.task),
      scope: str(rec.scope),
      acceptance: str(rec.acceptance),
      role: str(rec.role) || '开发成员',
      model: str(rec.model) || 'strong',
    };
    if (!card.title || !card.task || !card.acceptance) problems.push(`任务卡 ${card.id} 缺少 title、task 或 acceptance`);
    if (seen.has(card.id)) problems.push(`任务卡编号重复：${card.id}`);
    seen.add(card.id);
    if (!Object.prototype.hasOwnProperty.call(settings.models, card.model)) {
      problems.push(`任务卡 ${card.id} 的模型「${card.model}」不在模型名单里（可用：${Object.keys(settings.models).join(' / ')}）`);
    }
    return card;
  });
  for (let i = 0; i < cards.length; i += 1) {
    for (let j = i + 1; j < cards.length; j += 1) {
      const a = cards[i].scope;
      const b = cards[j].scope;
      if (a && b && (inScope(a, b) || inScope(b, a))) {
        problems.push(`任务卡 ${cards[i].id} 与 ${cards[j].id} 的写入范围重叠：${a} / ${b}——会改同一批文件的任务应合并成一张卡`);
      }
    }
  }
  return { cards, problems };
}

function cardTable(cards, settings) {
  const cell = (value) => String(value).replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');
  const lines = ['| 编号 | 任务 | 角色 | 写入范围 | 模型 | 验收标准 |', '|---|---|---|---|---|---|'];
  for (const card of cards) {
    const tier = TIER_NAMES[card.model] ?? '自定义';
    const model = `${card.model}（${tier}）· ${modelLabel(settings.models[card.model])}`;
    lines.push(`| ${cell(card.id)} | ${cell(card.title)} | ${cell(card.role)} | ${cell(card.scope || '未限定')} | ${cell(model)} | ${cell(card.acceptance)} |`);
  }
  return lines.join('\n');
}

const TEMPLATE_CARD = resolve(HERE, '..', 'templates', 'settings-card.html');

function loadTemplateCard() {
  if (!existsSync(TEMPLATE_CARD)) die(`找不到设置卡片模板：${TEMPLATE_CARD}`);
  return readFileSync(TEMPLATE_CARD, 'utf8');
}

function placeholder(name, value) {
  return `/*@@${name}@@*/${JSON.stringify(value)}/*@@END@@*/`;
}

/** 设置卡片是 HTML 片段模板：把 CURRENT / MODELS / SESSION_PROVIDER / SCRIPT 四个占位符换成真值。 */
export function buildCard(settings, candidates, sessionProvider) {
  const template = loadTemplateCard();
  const script = process.argv[1] ? process.argv[1].replace(/\\/g, '/') : '';
  return template
    .replace(placeholder('CURRENT', { x: 0 }), placeholder('CURRENT', settings))
    .replace(placeholder('MODELS', []), placeholder('MODELS', candidates))
    .replace(placeholder('SESSION_PROVIDER', ''), placeholder('SESSION_PROVIDER', sessionProvider))
    .replace(placeholder('SCRIPT', ''), placeholder('SCRIPT', script))
    .replace(/\/\*@@CURRENT@@\*\//, '')
    .replace(/\/\*@@MODELS@@\*\//, '')
    .replace(/\/\*@@SESSION_PROVIDER@@\*\//, '')
    .replace(/\/\*@@SCRIPT@@\*\//, '')
    .replace(/\/\*@@END@@\*\//g, '');
}

function commandCard(args) {
  const { settings } = loadSettings();
  const out = typeof args.out === 'string' ? resolve(args.out) : die('需要 --out <path> 指定卡片输出位置（会话可视化目录下的文件）');
  const candidatesPath = typeof args['models-file'] === 'string' ? resolve(args['models-file']) : die('需要 --models-file <path>（ListModels 的 JSON 输出）');
  let list;
  try {
    list = JSON.parse(readFileSync(candidatesPath, 'utf8'));
  } catch (error) {
    return die(`--models-file 不是合法 JSON：${error.message}`);
  }
  const sessionProvider = typeof args['session-provider'] === 'string' ? args['session-provider'] : '';
  const candidates = [];
  const seen = new Set();
  for (const item of Array.isArray(list) ? list : list.models ?? []) {
    const id = typeof item === 'string' ? item : typeof item?.id === 'string' ? item.id : '';
    if (!id || seen.has(id)) continue;
    seen.add(id);
    const disabled = typeof item === 'object' && item.disabled === true;
    const label = (typeof item === 'object' && typeof item.label === 'string' ? item.label : '') || id;
    candidates.push({ id, label: `${label}${disabled ? '（不可用）' : ''}` });
  }
  writeAtomic(out, buildCard(settings, candidates, sessionProvider));
  info(`设置卡片已生成：${out}`);
  info('会话内引用方式：在最终回复正文单独一行输出 ::visualize{"path":' + JSON.stringify(out).replace(/"/g, '"') + '}');
}

function showSettings(settings, source, asJson) {
  if (asJson) {
    process.stdout.write(`${JSON.stringify({ source, settings, workflow: OUTPUT, script: fileURLToPath(import.meta.url) }, null, 2)}\n`);
    return;
  }
  const lines = [`zcode-swarm 设置（${source === 'defaults' ? '默认值' : source}）`, '', '模型名单：'];
  for (const [key, id] of Object.entries(settings.models)) {
    lines.push(`  ${key}${TIER_NAMES[key] ? `（${TIER_NAMES[key]}）` : ''}：${id}`);
  }
  lines.push('', `审查员模型：${settings.review_model}`, `最多返工轮数：${settings.rework_rounds}`);
  process.stdout.write(`${lines.join('\n')}\n`);
}

const commands = {
  show(args) {
    const { settings, source } = loadSettings();
    showSettings(settings, source, Boolean(args.json));
  },
  set(args) {
    const { settings, problems } = validateSettings(readInput(args));
    if (!settings) die(`设置没有保存：\n  - ${problems.join('\n  - ')}`);
    writeAtomic(SETTINGS, `${JSON.stringify(settings, null, 2)}\n`);
    info(`设置已保存：${SETTINGS}`);
    render(settings);
    showSettings(settings, SETTINGS, false);
  },
  reset() {
    const settings = structuredClone(DEFAULTS);
    writeAtomic(SETTINGS, `${JSON.stringify(settings, null, 2)}\n`);
    info(`已恢复默认设置：${SETTINGS}`);
    render(settings);
    showSettings(settings, SETTINGS, false);
  },
  render(args) {
    render(loadSettings().settings, Boolean(args.quiet));
  },
  ensure(args) {
    ensure(Boolean(args.quiet));
  },
  'check-cards'(args) {
    const { settings } = loadSettings();
    const { cards, problems } = checkCards(readInput(args), settings);
    if (problems.length > 0) die(`任务卡没有通过校验：\n  - ${problems.join('\n  - ')}`);
    if (args.table) process.stdout.write(`${cardTable(cards, settings)}\n\n`);
    process.stdout.write(`${JSON.stringify(cards, null, 2)}\n`);
    info(`${cards.length} 张任务卡校验通过`);
  },
  card: commandCard,
};

const isMain = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = parseArgs(process.argv.slice(2));
  const command = commands[args._[0]];
  if (!command) {
    process.stdout.write(`${readFileSync(fileURLToPath(import.meta.url), 'utf8').split('*/')[0].replace(/^#!.*\n\/\*\*\n/, '').replace(/^ \* ?/gm, '')}\n`);
    process.exit(args._[0] ? 2 : 0);
  }
  command(args);
}
