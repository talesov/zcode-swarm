/* zcode-workflow
description: zcode-swarm
  团队开发：按已确认的任务卡分头施工，每张卡由独立审查员对照验收标准核对、不通过按意见返工，最后统一运行验证命令；全程在任务看板上展示进度。
whenToUse: 用户通过 /swarm 发布需求、并确认了拆单得到的任务卡之后，由主会话以已保存工作流启动。没有经用户确认的任务卡时不要直接运行。
args:
  requirement:
    type: string
    description: 本次团队开发的需求原文
    required: true
  cards:
    type: json
    description: 拆单后经用户确认的任务卡数组：[{id, title, task, scope, acceptance, role,
      model}]；model 是插件设置里的模型名单键（light / strong / hard 或自定义键）
    required: true
  gate:
    type: string
    description: 全部任务完成后运行的验证命令（项目的测试或构建命令）；空字符串表示不运行
    default: ""
  review_model:
    type: string
    description: 独立审查员使用的模型名单键
    default: strong
  rework_rounds:
    type: number
    description: 每张任务卡审查不通过时最多返工几轮（0-5），也是验证命令失败后最多修复几轮
    default: 2
*/
// zcode-swarm 团队开发工作流（由 zcode-swarm 插件管理）
// 模型名单块由 swarm-config.mjs 按插件设置生成：改模型请用 /swarm-settings，不要手改本文件。

// @@SWARM_MODELS_BEGIN
const MODELS: Record<string, ModelRef> = {
  light: model("GLM-5.3-Flash"),
  strong: model("GLM-5.3$high"),
  hard: model("GLM-5.3$max"),
};
const MODEL_LABELS: Record<string, string> = {
  light: "GLM-5.3-Flash",
  strong: "GLM-5.3 high",
  hard: "GLM-5.3 max",
};
// @@SWARM_MODELS_END

interface Card {
  id: string;
  title: string;
  task: string;
  scope: string;
  acceptance: string;
  role: string;
  model: string;
}

interface BuildResult {
  /** 本任务创建或修改过的每个文件，工作区相对路径。 */
  changed: string[];
  /** 一两句话：做了什么。 */
  summary: string;
  /** 实际运行过的自检命令及结果，每条一句；没有运行就给空数组。 */
  checks: string[];
  /** 没完成或拿不准的地方，每条一句；没有就给空数组。 */
  open: string[];
}

interface Verdict {
  /** 只有验收标准的每一条都有证据证明满足时才为 true。 */
  pass: boolean;
  /** 每个问题一条：位置（文件:行号）、问题是什么、为什么不满足验收标准。通过时给空数组。 */
  findings: string[];
  /** 实际核查了什么：读过的文件、运行过的命令，每条一句。 */
  checked: string[];
}

interface GateFix {
  /** 改动过的文件，工作区相对路径。 */
  changed: string[];
  /** 一两句话：判断的失败原因和做的修改。 */
  summary: string;
}

interface Outcome {
  card: Card;
  passed: boolean;
  rounds: number;
  summary: string;
  findings: string[];
  checked: string[];
  tampered: boolean;
  failure: string;
}

interface Finding {
  /** 位置：工作区相对路径（适用时带行号），或任务卡标题。 */
  where: string;
  /** 一句话：问题是什么。 */
  what: string;
  /** 依据：审查员的核查记录，或判定它的命令与输出。 */
  evidence: string;
  /** verified：命令或确定性检查判定；unconfirmed：只有单个审查员的判断。 */
  status: "verified" | "unconfirmed";
  /** 严重程度。high 只给数据损坏、崩溃或结果错误。 */
  severity: "low" | "medium" | "high";
}

interface WorkflowReport {
  /** 两三句话回答这次需求做成了什么。 */
  conclusion: string;
  findings: Finding[];
  /** 这次运行实际核查了什么、怎么核查的。 */
  verified: string[];
  /** 这次运行没有核查到的部分及原因。 */
  notCovered: string[];
}

const GATE_RUNNER =
  "const r=require('child_process').spawnSync(process.argv[1],{shell:true,stdio:'inherit'});" +
  "process.exit(r.status===null?1:r.status);";

const REVIEWER_PERSONA = [
  "你是独立审查员，任务是证明交付有问题——证明不了才判通过。",
  "只读取证，可以运行只读的检查命令；绝不修改、创建或删除任何文件，也不做任何 git 操作。",
  "逐条对照验收标准核对，每条结论都要有证据：文件:行号，或你实际运行的命令及输出。",
  "格式和风格上的个人偏好不构成不通过；不通过只留给：验收标准没达成、交付与任务卡不符、交付引入了缺陷。",
  "验收标准本身无法判定时，升级提问说清楚，不要猜。用中文回答。",
].join("\n");

const FIXER_PERSONA = [
  "你是集成修复员。所有任务卡都已完成，但整体验证命令没有通过，你负责找出原因并做最小修复。",
  "可以修改任何必要的文件，但不要重写别人已经完成的功能，也不要做任何 git 操作。",
  "修不好，或判断验证命令本身有问题时，升级提问说清楚，不要伪造通过。用中文回答。",
].join("\n");

function text(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function hasModel(key: string): boolean {
  return Object.prototype.hasOwnProperty.call(MODELS, key);
}

function normalizePath(value: string): string {
  return value.replace(/\\/g, "/").replace(/^\.\//, "").replace(/\/+$/, "").toLowerCase();
}

function inScope(path: string, scope: string): boolean {
  const p = normalizePath(path);
  const s = normalizePath(scope);
  return s.length > 0 && (p === s || p.startsWith(`${s}/`));
}

function parseCards(raw: unknown): Card[] {
  if (!Array.isArray(raw) || raw.length === 0) {
    throw new Error("参数 cards 必须是非空的任务卡数组");
  }
  const seen: string[] = [];
  const parsed = raw.map((entry: unknown, index: number): Card => {
    if (typeof entry !== "object" || entry === null) {
      throw new Error(`第 ${index + 1} 张任务卡不是对象`);
    }
    const rec = entry as Record<string, unknown>;
    const card: Card = {
      id: text(rec.id) || String(index + 1),
      title: text(rec.title),
      task: text(rec.task),
      scope: text(rec.scope),
      acceptance: text(rec.acceptance),
      role: text(rec.role) || "开发成员",
      model: text(rec.model) || "strong",
    };
    if (!card.title || !card.task || !card.acceptance) {
      throw new Error(`任务卡 ${card.id} 缺少 title、task 或 acceptance`);
    }
    if (seen.includes(card.id)) throw new Error(`任务卡编号重复：${card.id}`);
    seen.push(card.id);
    if (!hasModel(card.model)) {
      throw new Error(`任务卡 ${card.id} 的模型「${card.model}」不在插件设置的模型名单里`);
    }
    return card;
  });
  for (let i = 0; i < parsed.length; i += 1) {
    for (let j = i + 1; j < parsed.length; j += 1) {
      const a = parsed[i].scope;
      const b = parsed[j].scope;
      if (a && b && (inScope(a, b) || inScope(b, a))) {
        throw new Error(`任务卡 ${parsed[i].id} 与 ${parsed[j].id} 的写入范围重叠：${a} / ${b}`);
      }
    }
  }
  return parsed;
}

function builderName(card: Card): string {
  const role = card.role === "独立审查" ? "独立审查员" : card.role;
  return `${role}·任务${card.id}`;
}

function builderPersona(card: Card): string {
  return [
    `你是开发团队里的一名成员，角色是「${card.role}」。你只负责分配给你的这一张任务卡，其他任务卡由并行的同伴负责。`,
    card.scope
      ? `只能在写入范围「${card.scope}」内创建或修改文件；需要改范围外的文件时不要改，在结果里说明理由。`
      : "这张任务卡没有限定写入范围：只做任务需要的改动，并在结果里列出全部改动的文件。",
    "不要做任何 git 操作（提交、切分支、stash、reset 等）。",
    "完成后对照验收标准自查。验收标准无法达成或任务卡自相矛盾时，升级提问说清楚，不要绕过。用中文回答。",
  ].join("\n");
}

function buildAsk(requirement: string, card: Card): string {
  return [
    `团队这次的总需求：${requirement || "（见任务卡）"}`,
    "",
    `你的任务卡（编号 ${card.id}：${card.title}）：`,
    card.task,
    "",
    "验收标准：",
    card.acceptance,
    "",
    card.scope ? `写入范围：${card.scope}` : "写入范围：未限定",
    "完成后按要求的格式交回结果。",
  ].join("\n");
}

function reviewAsk(card: Card, work: BuildResult, gate: string): string {
  return [
    `请审查任务卡 ${card.id}「${card.title}」的交付。`,
    "",
    "任务：",
    card.task,
    "",
    "验收标准：",
    card.acceptance,
    "",
    card.scope ? `写入范围：${card.scope}` : "写入范围：未限定",
    `施工方报告改动的文件：${work.changed.length > 0 ? work.changed.join("、") : "（未报告）"}`,
    `施工方的说明：${work.summary}`,
    work.checks.length > 0 ? `施工方的自检：${work.checks.join("；")}` : "施工方没有报告自检。",
    gate
      ? "全部任务完成后脚本会统一运行验证命令，你不需要运行整套测试，只做判断验收标准所需的检查。"
      : "",
  ].join("\n");
}

function recheckAsk(work: BuildResult): string {
  return [
    "施工方已按你的意见返工。请重新逐条核对验收标准。",
    `施工方这次的说明：${work.summary}`,
    `改动的文件：${work.changed.length > 0 ? work.changed.join("、") : "（未报告）"}`,
  ].join("\n");
}

function reworkAsk(verdict: Verdict): string {
  return [
    "审查没有通过。请逐条处理下面的意见，仍然只在写入范围内修改，改完按同样格式交回结果：",
    ...verdict.findings.map((finding, index) => `${index + 1}. ${finding}`),
  ].join("\n");
}

function gateFixAsk(gate: string, exitCode: number, tail: string): string {
  return [
    `验证命令「${gate}」没有通过（退出码 ${exitCode}）。输出末尾如下：`,
    tail,
    "请找出原因并修复。脚本会在你之后重新运行验证命令，你不需要自己运行。",
  ].join("\n");
}

function boardRow(card: Card, stage: string, note: string) {
  return {
    id: card.id,
    title: `${card.id}. ${card.title}`,
    stage,
    role: card.role,
    model: MODEL_LABELS[card.model],
    note: note.length > 200 ? `${note.slice(0, 200)}…` : note,
  };
}

function cell(value: string): string {
  return value.replace(/\|/g, "\\|").replace(/\r?\n/g, " ");
}

let gitOk = true;

/** 写入范围内的 git 状态指纹：审查前后不一致，说明审查期间有人动了这张卡的文件。 */
async function scopeSnapshot(card: Card): Promise<string> {
  if (!gitOk || card.scope.length === 0) return "";
  try {
    const diff = await git.diff(undefined, card.scope);
    const status = await git.status();
    const untracked = status.untracked.filter((path) => inScope(path, card.scope)).sort();
    return `${diff}\n${untracked.join("\n")}`;
  } catch {
    return "";
  }
}

const requirement = text(args.requirement);
const cards = parseCards(args.cards);
const gate = text(args.gate);
const reviewKey = text(args.review_model) || "strong";
if (!hasModel(reviewKey)) {
  throw new Error(`审查模型「${reviewKey}」不在插件设置的模型名单里`);
}
const reworkArg = args.rework_rounds;
const reworkLimit =
  typeof reworkArg === "number" && Number.isFinite(reworkArg)
    ? Math.max(0, Math.min(5, Math.floor(reworkArg)))
    : 2;

artifact.board("team", {
  title: "团队任务看板",
  key: "id",
  status: "stage",
  columns: ["待施工", "施工中", "审查中", "返工中", "通过", "未通过"],
  cardTitle: "title",
  detail: [
    { field: "role", label: "角色" },
    { field: "model", label: "模型" },
    { field: "note", label: "进展" },
  ],
});
for (const card of cards) report(boardRow(card, "待施工", ""), "team");

let baseline: string[] = [];
try {
  baseline = await git.changedFiles();
} catch {
  gitOk = false;
}

phase("每张任务卡：分头施工、独立审查、按意见返工");
log(`共 ${cards.length} 张任务卡，审查使用 ${MODEL_LABELS[reviewKey]}，每张最多返工 ${reworkLimit} 轮`);
const outcomes = await Promise.all(
  cards.map(async (card): Promise<Outcome> => {
    const builder = agent(builderName(card), { system: builderPersona(card), model: MODELS[card.model] });
    const reviewer = agent(`独立审查·任务${card.id}`, { system: REVIEWER_PERSONA, model: MODELS[reviewKey] });
    const outcome: Outcome = {
      card,
      passed: false,
      rounds: 0,
      summary: "",
      findings: [],
      checked: [],
      tampered: false,
      failure: "",
    };

    report(boardRow(card, "施工中", "开始施工"), "team");
    let work: BuildResult;
    try {
      work = await builder.ask<BuildResult>(buildAsk(requirement, card));
    } catch (error) {
      outcome.failure = `施工没有交回有效结果：${String(error)}`;
      report(boardRow(card, "未通过", outcome.failure), "team");
      return outcome;
    }
    outcome.summary = work.summary;

    for (let round = 0; round <= reworkLimit; round += 1) {
      report(boardRow(card, "审查中", round === 0 ? "首次审查" : `第 ${round} 次返工后复审`), "team");
      const before = await scopeSnapshot(card);
      let verdict: Verdict;
      try {
        verdict = await reviewer.ask<Verdict>(round === 0 ? reviewAsk(card, work, gate) : recheckAsk(work));
      } catch (error) {
        outcome.failure = `审查没有交回有效结论：${String(error)}`;
        break;
      }
      const after = await scopeSnapshot(card);
      outcome.findings = verdict.findings;
      outcome.checked = verdict.checked;
      if (before !== after) {
        outcome.tampered = true;
        outcome.failure = "审查期间写入范围内的文件被改动，这次审查结论作废，需要人工复核";
        break;
      }
      if (verdict.pass) {
        outcome.passed = true;
        break;
      }
      if (round === reworkLimit) {
        outcome.failure = reworkLimit > 0 ? `返工 ${reworkLimit} 轮后仍未通过审查` : "未通过审查（设置为不返工）";
        break;
      }
      outcome.rounds = round + 1;
      report(boardRow(card, "返工中", verdict.findings[0] ?? "按审查意见修改"), "team");
      try {
        work = await builder.ask<BuildResult>(reworkAsk(verdict));
      } catch (error) {
        outcome.failure = `返工没有交回有效结果：${String(error)}`;
        break;
      }
      outcome.summary = work.summary;
    }
    report(
      boardRow(card, outcome.passed ? "通过" : "未通过", outcome.passed ? outcome.summary : outcome.failure),
      "team",
    );
    return outcome;
  }),
);

// 汇总要等全部任务卡结束：范围核查看的是整体改动。
const scopedCards = cards.filter((card) => card.scope.length > 0);
let outOfScope: string[] = [];
if (gitOk) {
  try {
    const changedNow = await git.changedFiles();
    outOfScope = changedNow.filter(
      (path) => !baseline.includes(path) && !scopedCards.some((card) => inScope(path, card.scope)),
    );
  } catch {
    gitOk = false;
  }
}

let gateRan = false;
let gatePassed = false;
let gateFixRounds = 0;
let gateTail = "";
if (gate) {
  phase("运行验证命令");
  let check = await world.run("node", ["-e", GATE_RUNNER, gate], {
    timeoutMs: 1_800_000,
    output: { tail: 16_384 },
  });
  if (check.exitCode !== 0 && reworkLimit > 0) {
    const fixer = agent("集成修复员", { system: FIXER_PERSONA, model: MODELS["hard"] });
    for (let round = 1; round <= reworkLimit && check.exitCode !== 0; round += 1) {
      phase("验证没过：修复后重跑");
      log(`验证命令没有通过，第 ${round} 轮修复`);
      gateFixRounds = round;
      const tail = `${check.stdout}\n${check.stderr}`.slice(-4000);
      await fixer.ask<GateFix>(gateFixAsk(gate, check.exitCode, tail));
      check = await world.run("node", ["-e", GATE_RUNNER, gate], {
        timeoutMs: 1_800_000,
        output: { tail: 16_384 },
      });
    }
  }
  gateRan = true;
  gatePassed = check.exitCode === 0;
  gateTail = `${check.stdout}\n${check.stderr}`.slice(-2000).trim();
}

const passedCount = outcomes.filter((outcome) => outcome.passed).length;
const findings: Finding[] = [];
for (const outcome of outcomes) {
  if (outcome.passed) continue;
  findings.push({
    where: outcome.card.scope || `任务卡 ${outcome.card.id}「${outcome.card.title}」`,
    what: outcome.failure || "未通过审查",
    evidence:
      outcome.findings.length > 0
        ? outcome.findings.join("；")
        : outcome.checked.length > 0
          ? outcome.checked.join("；")
          : "无",
    status: outcome.tampered ? "verified" : "unconfirmed",
    severity: outcome.tampered ? "high" : "medium",
  });
}
for (const path of outOfScope) {
  findings.push({
    where: path,
    what: "改动落在所有任务卡的写入范围之外",
    evidence: "运行前后的 git 改动对比",
    status: "verified",
    severity: scopedCards.length === cards.length ? "medium" : "low",
  });
}
if (gateRan && !gatePassed) {
  findings.push({
    where: gate,
    what: gateFixRounds > 0 ? `验证命令修复 ${gateFixRounds} 轮后仍未通过` : "验证命令没有通过",
    evidence: gateTail || "无输出",
    status: "verified",
    severity: "high",
  });
}

const gateLine = gateRan
  ? `验证命令 \`${gate}\`：${gatePassed ? "通过" : "未通过"}${gateFixRounds > 0 ? `（修复 ${gateFixRounds} 轮）` : ""}`
  : "没有配置验证命令";
const lines: string[] = [
  `# 团队施工报告：${passedCount}/${cards.length} 张任务卡通过`,
  "",
  `**需求**：${requirement || "（未提供）"}`,
  "",
  "| 任务卡 | 角色 | 模型 | 结果 | 返工 | 说明 |",
  "|---|---|---|---|---|---|",
  ...outcomes.map(
    (outcome) =>
      `| ${cell(`${outcome.card.id}. ${outcome.card.title}`)} | ${cell(outcome.card.role)} | ${cell(
        MODEL_LABELS[outcome.card.model],
      )} | ${outcome.passed ? "✅ 通过" : "❌ 未通过"} | ${outcome.rounds} | ${cell(
        outcome.passed ? outcome.summary : outcome.failure,
      )} |`,
  ),
  "",
  "## 验证",
  gateLine,
];
if (gateRan && gateTail) lines.push("", "```text", gateTail, "```");
if (findings.length > 0) {
  lines.push("", "## 需要你处理");
  for (const finding of findings) lines.push(`- **${finding.where}**：${finding.what}`);
}
await artifact.markdown("report", lines.join("\n"), {
  title: "团队施工报告",
  description: `${passedCount}/${cards.length} 张任务卡通过独立审查；${gateLine}。`,
  primary: true,
});

const verified: string[] = [`${cards.length} 张任务卡各由一名独立审查员逐条对照验收标准核对`];
if (gateRan) verified.push(gateLine);
if (gitOk) verified.push("运行前后的 git 改动对比：写入范围核查、审查员是否改动文件");
const notCovered: string[] = [];
if (!gateRan) notCovered.push("没有配置验证命令，整体没有用命令验证");
if (!gitOk) notCovered.push("工作区不是 git 仓库或 git 不可用，没有做写入范围核查和审查员改动检查");
if (gitOk && baseline.length > 0) notCovered.push(`运行前已有未提交改动的 ${baseline.length} 个文件不参与写入范围核查`);
if (gitOk) notCovered.push("审查员对未跟踪文件内容的修改检测不到");
if (scopedCards.length < cards.length) notCovered.push("没有写入范围的任务卡无法做越界和审查员改动检查");

const result: WorkflowReport = {
  conclusion:
    `${passedCount}/${cards.length} 张任务卡通过独立审查；${gateLine}` +
    (outOfScope.length > 0 ? `；有 ${outOfScope.length} 处改动超出写入范围` : "") +
    "。",
  findings,
  verified,
  notCovered,
};
return result;
